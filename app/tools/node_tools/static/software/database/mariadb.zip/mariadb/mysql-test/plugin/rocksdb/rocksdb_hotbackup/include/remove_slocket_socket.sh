src_data_dir="${MYSQLTEST_VARDIR}/mysqld.1/data/"
rm "${src_data_dir}/slocket"
