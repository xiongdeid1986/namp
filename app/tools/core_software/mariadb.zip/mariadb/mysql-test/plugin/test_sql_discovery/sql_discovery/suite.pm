package My::Suite::SQL_Discovery;
@ISA = qw(My::Suite);

sub is_default { 1 }

bless { };

